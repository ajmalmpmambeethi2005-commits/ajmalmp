let attendance = ['P', 'P', 'A', 'P', 'A', 'P', 'P'];

let present = 0;
let absent = 0;

for (let i = 0; i < attendance.length; i++) {
    if (attendance[i] === 'P') {
        present++;
    } else if (attendance[i] === 'A') {
        absent++;
    }
}

let percentage = (present / attendance.length) * 100;

console.log("Present Days:"+ present);
console.log("Absent Days:"+ absent);
console.log("Attendance Percentage:"+percentage.toFixed(2) + " % ");