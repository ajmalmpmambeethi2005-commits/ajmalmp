let array = [40, 53, 15, 33, 45, 98, 67, 46, 57];

for (let i = 0; i < array.length; i++) {
    if (array[i] % 3 === 0  &&  array[i]  % 5 === 0) {


        console.log(array[i]);
    }
}