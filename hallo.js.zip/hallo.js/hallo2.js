let hours = 10;
let fee = 0;

if (hours <= 2) {
     fee = 2 * 20;

} else if 
    (hours <= 5) {
    fee = (2 * 20) + ((hours - 2) * 15);


} else {
     fee = (2 * 20) + (3 * 15) + ((hours - 5) * 10);
}

console.log("Total Parking Fee :"+ fee);